export const colors = {
  black: '#000000',
  white: '#ffffff',
  grey: '#ebedf0',
  transparentBlack: 'rgba(0,0,0,.25)'
};

import React from 'react';
const bookasession = (props) => {
  return(
    <div>Book a Session</div>
  )
}

export default (bookasession);
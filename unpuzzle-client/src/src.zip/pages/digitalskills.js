import React from 'react';
const DigitalSkills = (props) => {
  return(
    <div>Digital Skills</div>
  )
}

export default (DigitalSkills);
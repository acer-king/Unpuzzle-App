import React from 'react';
const GradeSchool = (props) => {
  return(
    <div>Grade School</div>
  )
}

export default (GradeSchool);
import React from 'react';
const InnovationInEducation = (props) => {
  return(
    <div>Innovation in Education</div>
  )
}

export default (InnovationInEducation);
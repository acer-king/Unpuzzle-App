import React from 'react';
const PuzzleWorld = (props) => {
  return(
    <div>Puzzle World</div>
  )
}

export default (PuzzleWorld);
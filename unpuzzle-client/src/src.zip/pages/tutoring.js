import React from 'react';
import { Link } from 'react-router-dom';
const Tutoring = (props) => {
  return(
    <div>Tutoring</div>
  )
}

export default (Tutoring);